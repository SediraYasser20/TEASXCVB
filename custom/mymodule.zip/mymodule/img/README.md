
Directory for module image files
--------------------------------

You can put here the .png files of your module:


If the picto of your module is an image (property $picto has been set to 'mymodule.png@mymodule', you can put into this
directory a .png file called *object_mymodule.png* (16x16 or 32x32 pixels)


If the picto of an object is an image (property $picto of the object.class.php has been set to 'myobject.png@mymodule', then you can put into this
directory a .png file called *object_myobject.png* (16x16 or 32x32 pixels)

