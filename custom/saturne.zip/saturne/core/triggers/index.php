<?php
//Silence is golden apple
