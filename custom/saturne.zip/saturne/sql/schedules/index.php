*<?php
// Silence is golden
